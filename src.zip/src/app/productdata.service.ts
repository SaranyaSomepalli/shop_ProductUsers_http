import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductdataService {

  constructor(private http:HttpClient) { }

  getAllProducts(): Observable<Array<Object>>{
    //  return this.data;
    return this.http.get<Array<Object>>('https://5cdd0a92b22718001417c19d.mockapi.io/api/products')
  }
    getProductById(id:number):Observable<Object>{
       // return this.data.find(p => p.id == id);
       return this.http.get(`https://5cdd0a92b22718001417c19d.mockapi.io/api/products/${id}`)
    }

    addProduct(dataObj:any){
    /*  dataObj.id = this.data.length+1;
      dataObj.image = "https://assetscdn1.paytm.com/images/catalog/product/K/KI/KIDURBAN-SCOTTIURBA589647EA42B8EF/1563266629257_0..jpg"
      this.data.push(dataObj)
     */ 
    return this.http.post('https://5cdd0a92b22718001417c19d.mockapi.io/api/products',dataObj)

    }
    updateProduct(id:number,dataObj:any){
   /*  let findObj = this.data.findIndex((obj) => {
        return obj.id == id
      })
      console.log(findObj)
      dataObj.id = id;
      dataObj.image = "https://assetscdn1.paytm.com/images/catalog/product/K/KI/KIDURBAN-SCOTTIURBA589647EA42B8EF/1563266629257_0..jpg"
      this.data[findObj]  = dataObj;
    */
   return this.http.put(`https://5cdd0a92b22718001417c19d.mockapi.io/api/products/${id}`,dataObj)
    }
    
    getLength(){
    // return this.data.length;
    }

   removeForm(i:number){
  //    this.data.splice(i,1);
    }
}
