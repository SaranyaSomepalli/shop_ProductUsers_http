import { Component, OnInit } from '@angular/core';
import { ProductdataService} from "../productdata.service";
import { UserdataService } from '../userdata.service';

@Component({
  selector: 'app-dashcontent',
  templateUrl: './dashcontent.component.html',
  styleUrls: ['./dashcontent.component.css']
})
export class DashcontentComponent implements OnInit {
  productLength:number=0;
  userLength:number=0;
constructor(private userdataService:UserdataService,private productdataService:ProductdataService) { }

  ngOnInit(): void {
    this.productdataService.getAllProducts().subscribe((data)=>{
      
      this.productLength=data.length;
    });
      this.userdataService.getAllUsers().subscribe((data1)=>{
         this.userLength=data1.length;
      });
     
    
   
  }

}
