import { ValueConverter } from "@angular/compiler/src/render3/view/template";

export interface userData{
        id:number,
        name:string,
        email:string,
        description:string,
        username1:string,
        gender1:string,
        email1:string,
        mobile1:string,
        image1:string
}