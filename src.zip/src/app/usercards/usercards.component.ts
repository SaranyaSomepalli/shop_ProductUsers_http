import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { userData } from '../model1';
import {UserdataService} from '../userdata.service'

@Component({
  selector: 'app-usercards',
  templateUrl: './usercards.component.html',
  styleUrls: ['./usercards.component.css']
})
export class UsercardsComponent implements OnInit {
  @Input('userData') userData:Partial<userData> = {}
  constructor() { }

  ngOnInit(): void {
  }

}
