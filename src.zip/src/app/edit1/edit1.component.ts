import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup,FormArray, FormBuilder, Validators} from "@angular/forms";
import { ActivatedRoute, Router } from '@angular/router';
import { UserdataService } from "../userdata.service";
import {Observable} from 'rxjs';

@Component({
  selector: 'app-edit1',
  templateUrl: './edit1.component.html',
  styleUrls: ['./edit1.component.css']
})
export class Edit1Component implements OnInit {

  userFormGroup:any;
  constructor(private activatedRoute: ActivatedRoute,private fb:FormBuilder, private userdataService: UserdataService,private router:Router) { }



  ngOnInit(): void {

    
    let currentId = this.activatedRoute.snapshot.params.id;
     this.userdataService.getUserById(currentId).subscribe((currentUser:any)=>{
      this.userFormGroup = this.fb.group({
        name : this.fb.control(currentUser.name,[Validators.required,Validators.minLength(5),Validators.maxLength(50)]),
        email : this.fb.control(currentUser.email,Validators.required),
        description : this.fb.control(currentUser.description,[Validators.required]),
        username1 : this.fb.control(currentUser.username1,Validators.required),
        gender1 : this.fb.control(currentUser.gender1,Validators.required),
        email1 : this.fb.control(currentUser.email1,Validators.required),
        mobile1 : this.fb.control(currentUser.mobile1,Validators.required),
       
      
      })
     })
    
  }
  submitForm(){
    console.log(this.userFormGroup.get("name").errors)
    if(this.userFormGroup.valid){
      console.log(this.userFormGroup.value);
      this.userdataService.updateUser(this.activatedRoute.snapshot.params.id,this.userFormGroup.value).subscribe((data:any) =>{
        console.log(this.userFormGroup.value);
        this.userFormGroup.reset()
        //this.router.navigate(['productlist'])
      })
    
  

    }else{
      this.validateAllFormFields(this.userFormGroup)
    }
  }

  validateAllFormFields(formGroup: FormGroup){
    Object.keys(formGroup.controls).forEach(field =>{
      const control = formGroup.get(field);
      if(control instanceof FormControl){
        control.markAsTouched({onlySelf:true});
      }
      else if(control instanceof FormGroup){
        this.validateAllFormFields(control);
      }
      
    });
  }

}
