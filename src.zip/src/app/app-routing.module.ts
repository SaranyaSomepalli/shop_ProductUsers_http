import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { CreateProductComponent } from './create-product/create-product.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DashcontentComponent } from './dashcontent/dashcontent.component';
import { EditComponent } from './edit/edit.component';
import { Edit1Component } from './edit1/edit1.component';
import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';
import { ProductsComponent } from './products/products.component';
import { ServicesComponent } from './services/services.component';
import { UserComponent } from './user/user.component';
import { UsersComponent } from './users/users.component';

const routes: Routes = [{
  path:'',
  component:ProductsComponent
},
{
  path:'',
  component:HomeComponent
},
{
  path:'about',
  component:AboutComponent
},
{
  path:'services',
  component:ServicesComponent
},
{
  path:'contact',
  component:ContactComponent
},
{
  path:'users',
  component:UsersComponent
},
{
  path:'dashboard',
  component:DashcontentComponent
},

{
  path:'product-create',
  component:CreateProductComponent
},
{
  path:'user-create',
  component:CreateUserComponent
},
{
  path:"product/:id",
  component:ProductComponent
},
{
  path:"user/:id",
  component:UserComponent
},
{
  path:"product/edit/:id",
  component:EditComponent
},
{
  path:"users/edit1/:id",
  component:Edit1Component
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
