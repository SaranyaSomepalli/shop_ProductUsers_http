import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserdataService {



  constructor(private http:HttpClient) { }

  getAllUsers(): Observable<Array<Object>>{
   // return this.datau;
   return this.http.get<Array<Object>>('https://5cdd0a92b22718001417c19d.mockapi.io/api/users')
}
getUserById(id:number):Observable<Object>{
//  return this.datau.find(p => p.id == id);
return this.http.get(`https://5cdd0a92b22718001417c19d.mockapi.io/api/users/${id}`)
}
addUser(dataObj:any){
//  dataObj.id = this.datau.length+1;
 // dataObj.image = "https://www.realtechnirman.com/wp-content/uploads/2017/02/man-dummy.jpg"
 // this.datau.push(dataObj)
 return this.http.post('https://5cdd0a92b22718001417c19d.mockapi.io/api/users',dataObj)

}
updateUser(id:number,dataObj:any){
 // let findObj = this.datau.findIndex((obj) => {
  //  return obj.id == id
 // })
 // console.log(findObj)
 // dataObj.id = id;
 // dataObj.image ="https://www.realtechnirman.com/wp-content/uploads/2017/02/man-dummy.jpg"
 // this.datau[findObj]  = dataObj;
 return this.http.put(`https://5cdd0a92b22718001417c19d.mockapi.io/api/users/${id}`,dataObj)
}
getLength(){
 // return this.datau.length;
}
  
}
