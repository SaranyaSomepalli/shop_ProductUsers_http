import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import{UserdataService} from "../userdata.service"

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  userObject:any ={};
  constructor(private activatedRoute:ActivatedRoute,private dataservice:UserdataService) { }

  ngOnInit(): void {
    console.log(this.activatedRoute.snapshot.params.id)
     this.dataservice.getUserById(this.activatedRoute.snapshot.params.id).subscribe((data)=>{
      this.userObject = data
     })
     
  }

}
